package arie.footballclub

data class Item (val nama: String?, val image: Int?)